package com.example.snake.model;

public class Data {

    public static String text ="";
}
