package example;

public class HighScore {
}
