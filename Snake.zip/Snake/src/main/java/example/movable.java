package example;

/**
 * 
 * @Project Snakee
 * @Description Fyrsta viðmótið
 * @Author Sigurður Sigurðardóttir
 * @version Ekki viss
 */ 

public interface movable
{
	void move();
}
