package example;

public class HighScoreManager {
}
