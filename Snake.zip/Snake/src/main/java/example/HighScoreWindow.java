package example;

public class HighScoreWindow
{
}
